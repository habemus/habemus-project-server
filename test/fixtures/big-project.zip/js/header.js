(function (bigcase) {
  
  var $navTrigger = $('#nav-trigger');
  var $nav = $('#nav');
  
  $navTrigger.on('click', function () {
    bigcase.toggleNav();
  });
    
  bigcase.toggleNav = function () {
    $nav.toggleClass('open');
    $navTrigger.toggleClass('open');
  };
  
  $('#nav').onePageNav({
    currentClass: 'active',
    changeHash: false,
    scrollSpeed: 750,
    scrollThreshold: 0.5,
    scrollOffset: -1 * parseInt($('#header').height()),
    filter: '',
    easing: 'swing',
    begin: function() {
      //I get fired when the animation is starting
      bigcase.toggleNav();
    },
    end: function() {
      //I get fired when the animation is ending
    },
    scrollChange: function($currentListItem) {
      //I get fired when you enter a section and I pass the list item of the section
    }
  });
  
})(window.bigcase);